#!/usr/bin/env python3
"""Сборка единого портала из цифровых раздаток МК-01 и МК-02."""

import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROJECT = ROOT.parent
PORTAL_ASSETS = ROOT / "assets"
FONT_SRC = Path("/usr/share/fonts/otf/RostelecomBasis")

NAV = [
    ("МК №1 · Промпт-инжиниринг", [
        ("mk1-rules", "5 правил промпта", PROJECT / "МК-01/05_Раздатки_цифровые/5_правил_промпта.html"),
        ("mk1-safety", "Безопасность ИИ", PROJECT / "МК-01/05_Раздатки_цифровые/Чек-лист_безопасности_ИИ.html"),
        ("mk1-services", "Карта сервисов", PROJECT / "МК-01/05_Раздатки_цифровые/Карта_сервисов_для_учителя.html"),
        ("mk1-prompts", "Промпты для учителя", PROJECT / "МК-01/05_Раздатки_цифровые/Промпты_для_учителя.html"),
    ]),
    ("МК №2 · ИИ-агенты", [
        ("mk2-create", "Как создать помощника", PROJECT / "МК-02/05_Раздатки_цифровые/Как_создать_ИИ-помощника.html"),
        ("mk2-template", "Шаблон системного промпта", PROJECT / "МК-02/05_Раздатки_цифровые/Шаблон_системного_промпта.html"),
        ("mk2-examples", "Примеры агентов", PROJECT / "МК-02/05_Раздатки_цифровые/Примеры_агентов_для_учителя.html"),
        ("mk2-testing", "Тестирование агента", PROJECT / "МК-02/05_Раздатки_цифровые/Чек-лист_тестирования_агента.html"),
    ]),
]

HOME_CARDS = [
    ("mk1-rules", "МК №1", "5 правил промпта", "Формула, техники, частые ошибки"),
    ("mk1-safety", "МК №1", "Безопасность ИИ", "Что можно и нельзя загружать в нейросеть"),
    ("mk1-services", "МК №1", "Карта сервисов", "Какую нейросеть выбрать под задачу"),
    ("mk1-prompts", "МК №1", "Промпты для учителя", "15+ готовых шаблонов"),
    ("mk2-create", "МК №2", "Создать ИИ-помощника", "ChatGPT GPT и Claude Projects"),
    ("mk2-template", "МК №2", "Системный промпт", "Шаблон и промпты генерации"),
    ("mk2-examples", "МК №2", "Примеры агентов", "6 идей для школы"),
    ("mk2-testing", "МК №2", "Тестирование", "3 уровня запросов и чек-лист"),
]


def extract_doc(html: str) -> str:
    m = re.search(r'<div class="doc">(.*?)</div>\s*(?:<script|</body>)', html, re.DOTALL)
    if not m:
        raise ValueError("Не найден блок .doc")
    content = m.group(1).strip()
    content = re.sub(r'<div class="footer-note">[^<]*Ctrl\+P[^<]*</div>', '<div class="footer-note">СтажИИровка для учителей 2026</div>', content)
    return content


def build_nav() -> str:
    parts = ['<a href="#home" class="nav-link" data-section="home">Главная</a>']
    for label, items in NAV:
        parts.append(f'<div class="nav-group"><div class="nav-group-label">{label}</div>')
        for sid, title, _ in items:
            parts.append(f'<a href="#{sid}" class="nav-link" data-section="{sid}">{title}</a>')
        parts.append("</div>")
    return "\n".join(parts)


def build_home() -> str:
    cards = []
    for sid, mk, title, desc in HOME_CARDS:
        cards.append(f"""<a href="#{sid}" class="home-card" data-section="{sid}">
      <div class="mk-tag">{mk}</div>
      <h3>{title}</h3>
      <p>{desc}</p>
    </a>""")
    return f"""<section id="home" class="portal-section portal-home active">
  <div class="hero">
    <div class="tag">СтажИИровка для учителей 2026</div>
    <h2>Материалы мастер-классов</h2>
    <p>Бонусные раздатки с МК №1 и МК №2 — промпты, безопасность, сервисы и создание ИИ-помощников. Выберите раздел слева или ниже.</p>
  </div>
  <div class="home-grid">{''.join(cards)}</div>
</section>"""


def build_sections() -> str:
    parts = []
    for _, items in NAV:
        for sid, _, path in items:
            html = path.read_text(encoding="utf-8")
            doc = extract_doc(html)
            parts.append(f'<section id="{sid}" class="portal-section">\n{doc}\n</section>')
    return "\n".join(parts)


def merge_prompts() -> str:
    mk1 = (PROJECT / "МК-01/assets/prompts.js").read_text(encoding="utf-8")
    mk2 = (PROJECT / "МК-02/assets/prompts.js").read_text(encoding="utf-8")
    return mk1 + "\n" + mk2


def copy_fonts() -> None:
    dest = PORTAL_ASSETS / "fonts"
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("Light", "Regular", "Medium", "Bold"):
        src = FONT_SRC / f"RostelecomBasis-{name}.otf"
        if src.exists():
            shutil.copy2(src, dest / src.name)


def build_index() -> None:
    html = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>СтажИИровка 2026 — материалы для учителей</title>
  <link rel="stylesheet" href="assets/handout-style.css">
</head>
<body>
  <button class="nav-toggle" type="button" aria-label="Меню">☰ Меню</button>
  <div class="portal-layout">
    <nav class="portal-nav">
      <div class="nav-brand">
        <h1>СтажИИровка<br>для учителей 2026</h1>
        <p>Материалы МК №1 и МК №2</p>
      </div>
      {build_nav()}
    </nav>
    <main class="portal-main">
      {build_home()}
      {build_sections()}
    </main>
  </div>
  <script src="assets/prompts.js"></script>
  <script src="assets/portal.js"></script>
</body>
</html>
"""
    (ROOT / "index.html").write_text(html, encoding="utf-8")


def main() -> None:
    copy_fonts()
    (PORTAL_ASSETS / "prompts.js").write_text(merge_prompts(), encoding="utf-8")
    build_index()
    print(f"OK  {ROOT / 'index.html'}")


if __name__ == "__main__":
    main()
